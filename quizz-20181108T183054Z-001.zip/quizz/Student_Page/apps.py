from django.apps import AppConfig


class StudentPageConfig(AppConfig):
    name = 'Student_Page'
